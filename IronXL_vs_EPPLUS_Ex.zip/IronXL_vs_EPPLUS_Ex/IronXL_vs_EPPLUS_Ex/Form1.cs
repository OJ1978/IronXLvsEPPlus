﻿using OfficeOpenXml;
using System;
using System.IO;
using System.Windows.Forms;
using IronXL;
using System.Globalization;
using System.Threading;
using System.Text;
using OfficeOpenXml.Style;
using System.Drawing;

namespace IronXL_vs_EPPLUS_Ex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var file = new FileInfo(@"c:\temp\EPPlusWorkbook.xlsx");
            using (var package = new ExcelPackage(file))
            {
                var sheet = package.Workbook.Worksheets.Add("My Sheet");
                sheet.Cells["A1"].Value = "EPPlus";

                // Save to file
                package.Save();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            WorkBook workbook = WorkBook.Create(ExcelFileFormat.XLSX);
            var sheet = workbook.CreateWorkSheet("My Sheet");
            sheet["A1"].Value = "IronXL";
            workbook.SaveAs("IronXLWorkbook");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // set the formatting options
            ExcelTextFormat format = new ExcelTextFormat();
            format.Delimiter = ';';
            format.Culture = new CultureInfo(Thread.CurrentThread.CurrentCulture.ToString());
            format.Culture.DateTimeFormat.ShortDatePattern = "dd-mm-yyyy";
            format.Encoding = new UTF8Encoding();

            //read the CSV file from disk
            FileInfo file = new FileInfo("C:\\EPPlusCSVDemo.csv");

            //create a new Excel package
            using (ExcelPackage excelPackage = new ExcelPackage())
            {
                //create a WorkSheet
                ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Sheet 1");

                //load the CSV data into cell A1
                worksheet.Cells["A1"].LoadFromText(file, format);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WorkBook workbook = WorkBook.LoadCSV("IronXLCSVDemo.csv", fileFormat: ExcelFileFormat.XLSX, ListDelimiter: ",");
            WorkSheet ws = workbook.DefaultWorkSheet;
            workbook.SaveAs("Students.xlsx");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var file = new FileInfo(@"c:\temp\EPPlusFormatting.xlsx");
            using (var package = new ExcelPackage(file))
            {
                var worksheet = package.Workbook.Worksheets.Add("My Sheet");
                using (var range = worksheet.Cells[1, 1, 1, 5])  //Address "A1:A5" 
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.DarkBlue);
                    range.Style.Font.Color.SetColor(Color.White);
                }

                // Save to file
                package.Save();
            }
            

        }
    }
}
